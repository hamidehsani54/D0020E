package main

// import (
// 	q "providerConsumer/registartionAndQueryForms"
// )

// func provideSystemSpecs(system *q.System) {

// 	system.SystemName = systemName
// 	system.Address = systemIpAddress
// 	system.Port = systemPort
// 	system.Authenication = ""
// 	system.Protocol = nil

// }

// func provideServiceSpecs(service *q.Service) {

// 	service.ServiceDefinition = getTempratureServiceDefinition
// 	service.ServiceName = getTemperatureServiceName
// 	service.Path = getTemperatureServicePath
// 	service.Metadata = append(service.Metadata, getTemperatureSensorID, indoor, Celsius)
// 	service.Version = CurrentVersion

// }
